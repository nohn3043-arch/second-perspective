import uuid
from dataclasses import dataclass

@dataclass
class ResponsibilityAccount:
    organization: str
    role: str
    stage: str
    nonce: str = uuid.uuid4().hex[:8]

class CognitiveAuditEngine:
    ALLOWED_STAGES = {"PRE_DECISION", "COMPARISON"}

    def __init__(self, account: ResponsibilityAccount):
        if account.stage not in self.ALLOWED_STAGES:
            raise ValueError(f"Only allowed stages: {self.ALLOWED_STAGES}")
        self.account = account

    def audit(self, decision_context: str):
        return {
            "disclaimer_first": "This tool only audits cognitive bias. It does not make decisions.",
            "responsibility_account": {
                "org": self.account.organization,
                "role": self.account.role,
                "stage": self.account.stage,
                "unique_id": self.account.nonce
            },
            "analysis": {
                "hidden_assumptions": [
                    "Assumes future trend continues linearly",
                    "Assumes stable external environment",
                    "Single success path dependency"
                ],
                "uncertainties": [
                    "Market/public reaction uncertainty",
                    "Long-term unintended consequences",
                    "External shock risk"
                ],
                "cognitive_biases": [
                    "Overconfidence bias",
                    "Narrative lock-in",
                    "Groupthink potential"
                ]
            },
            "disclaimer_final": "All decision responsibility remains with the user."
        }

if __name__ == "__main__":
    account = ResponsibilityAccount(
        organization="GLOBAL_ENTERPRISE",
        role="STRATEGY",
        stage="PRE_DECISION"
    )
    engine = CognitiveAuditEngine(account)
    report = engine.audit("Sample strategic decision")
    import json
    print(json.dumps(report, indent=2))